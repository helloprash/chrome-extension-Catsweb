import os, inspect
from bs4 import BeautifulSoup as BS
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException
from flask import Flask, render_template, request, jsonify
import steps

def checkCM(htmlSource):
    soup = BS(htmlSource, "lxml")
    bold = soup.find_all('b')
    for eachText in bold:
        if eachText.text.strip() == 'Complaint Manager Home Page':
            return True
    return False

def actionSubmit(browser,ID):
    browser.find_element_by_id('CTRLRECORDTYPE2').click() #Action Radio
    browser.find_element_by_xpath('//*[@id="CTRLRECORDIDTO"]').send_keys(ID) #CWID 
    browser.find_element_by_xpath('//*[@id="CTRLSubmitCommonPageTop"]').click() #Submit
    return browser
    
def getCFDetails(htmlSource):
    soup = BS(htmlSource, "lxml")
    center = soup.find_all('center')
    tables = soup.find_all('table',{'id':'TBCALogForm'})

    #Username
    td = [tr.find_all('td', {'id':'TDAssignedTo'}) for tr in tables[0].find_all('tr')]
    for eachtd in td:
        if eachtd:
            data = [each.find('br').next_sibling for each in eachtd]
    username = data[0].text.strip()

    #RDPC
    td = [tr.find_all('td', {'id':'TDStandardMemo013'}) for tr in tables[0].find_all('tr')]
    for eachtd in td:
        if eachtd:
            data = [each.find('font') for each in eachtd]
    RDPC = data[0].text.strip()
    
    #Current step
    td = [tr.find_all('td', {'id':'TDStandardText003'}) for tr in tables[0].find_all('tr')]
    for eachtd in td:
        if eachtd:
            data = [each.find('font') for each in eachtd]
    step = data[0].text.strip()

    #Product
    p_tag = soup.find(text='Products').parent
    font_tag = p_tag.parent
    center_tag = font_tag.parent
    next_center_tag = center_tag.findNext('center').findNext('center')
    tables = next_center_tag.find_all('table',{'id':'TBGenericRecs0'})
    td = [tr.find_all('td', {'id':'TDRowItem16'}) for tr in tables[0].find_all('tr')]
    for eachtd in td:
        if eachtd:
            data = [each.find('font') for each in eachtd]
    product = data[0].text.strip()

    #Investigation report
    try:
        ir_tag = soup.find(text='Investigation Requests').parent
        font_tag = ir_tag.parent
        center_tag = font_tag.parent
        next_center_tag = center_tag.findNext('center').findNext('center')
        tables = next_center_tag.find_all('table',{'id':'TBGenericRecs0'})
        td = [tr.find_all('td', {'id':'TDRowItem11'}) for tr in tables[0].find_all('tr')]
        td1 = [tr.find_all('td', {'id':'TDRowItem13'}) for tr in tables[0].find_all('tr')]
        for eachtd, eachtd1 in zip(td,td1):
            if (eachtd,eachtd1):
                data = [each.find('font') for each in eachtd]
                data1 = [each.find('font') for each in eachtd1]
        IRnum = data[0].text.strip()
        IRstep = data1[0].text.strip()
        IR = True
    except AttributeError:
        IR = False
        IRstep = 'XX'
        IRnum = 'XXXX'
    
    return(username,RDPC,step,product,IR,IRstep,IRnum)




app = Flask(__name__)
 
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/complaint/', methods=['POST'])
def initialization():
    CFnum = int(request.form.get('number', 0))
    url = 'http://cwqa/CATSWebNET/main.aspx?WCI=Main&WCE=ViewDashboard&WCU=s%3d1XRZX54UI5GR3N2QTM3Y7M4INJTW8JKS%7c*~r%3dComplaint%20Owner%20Home%20Page%7c*~q%3d1%7c*~g%3d0'
    
    current_folder = os.path.realpath(os.path.abspath(os.path.split(inspect.getfile(inspect.currentframe() ))[0]))
    pjs_file = '\\\\'.join(os.path.join(current_folder,"chromedriver.exe").split('\\'))

    browser = webdriver.Chrome(pjs_file)
    
    browser.get(url)

    CM = checkCM(browser.page_source)
    if CM:
        browser.find_element_by_xpath('//*[@id="TDDisplayPart004"]/font/a/font').click()

    browser = actionSubmit(browser,CFnum)
        
    (username,RDPC,current_step,product,IR,IRstep,IRnum) = getCFDetails(browser.page_source)
    print(username,RDPC,current_step,product,IR,IRstep,IRnum)
        
    process_steps = {
                        '050':steps.step90,
                        '090':steps.step140,
                        '140':steps.step999
                    }
    if IR and IRstep != '999':
        data = {'newData': 'IR still open in step {}'.format(IRstep)}
        data = jsonify(data)
        browser.quit()
        return data
        print('IR still open in step {}'.format(IRstep))
    elif len(username) == 0 or len(RDPC) == 0  or len(product) == 0:
        data = {'newData': 'Complaint folder not processable. Kindly check RDPC or product records.'}
        data = jsonify(data)
        browser.quit()
        return data
        print('Complaint folder not processable. Kindly check RDPC or product records.')
    else:
        try:
            if not IR and (RDPC == 'Failure to Capture' or RDPC == 'Loss of Capture' or RDPC == 'Fluid Catchment Filled') and (product == 'LOI' or product == '0180-1201' or product == '0180-1401'):
                process_steps['090'](browser, CFnum, RDPC=RDPC, product=product, username=username,IR=IR,IRnum=IRnum)
            else:
                process_steps[current_step](browser, CFnum, RDPC=RDPC, product=product, username=username,IR=IR,IRnum=IRnum)
        except KeyError:
            data = {'newData': 'Error! The current step is {}'.format(current_step)}
            data = jsonify(data)
            browser.quit()
            return data
            print('Error! The current step is {}'.format(current_step))

        
 
if __name__ == '__main__':
    app.run(debug=True)





    



    


